interface Category {
    id: string;
    name: string;
    count: number;
}

export default Category;