const ProductList = () => {
    return (
        <div className="w-4xl min-h-64 mb-8 py-8 px-[52px] border-1 border-[#CBD5E1] rounded-md">
            В разработке...
        </div>
    )
}

export default ProductList;