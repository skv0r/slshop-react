export { default as Banner } from './Banner/Banner'
export { default as PopularProducts } from './PopularProducts/PopularProducts'
export { default as About } from './About/About' 